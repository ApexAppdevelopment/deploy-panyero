import { getWallet, createWallet, updateWalletBalance } from '@/lib/wallet-service'
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore'

jest.mock('firebase/firestore', () => ({
  doc: jest.fn(),
  getDoc: jest.fn(),
  setDoc: jest.fn(),
  updateDoc: jest.fn(),
  collection: jest.fn(),
  query: jest.fn(),
  where: jest.fn(),
  getDocs: jest.fn(),
}))

describe('Wallet Service', () => {
  beforeEach(() => {
    jest.clearAllMocks()
  })

  describe('getWallet', () => {
    it('should return null if wallet not found', async () => {
      const mockGetDocs = getDocs as jest.MockedFunction<typeof getDocs>
      mockGetDocs.mockResolvedValueOnce({ empty: true, docs: [] } as any)

      const result = await getWallet('nonexistentUserId')
      expect(result).toBeNull()
    })

    it('should return wallet if found', async () => {
      const mockWallet = { id: 'walletId', balance: 100, currency: 'PHP' }
      const mockGetDocs = getDocs as jest.MockedFunction<typeof getDocs>
      mockGetDocs.mockResolvedValueOnce({
        empty: false,
        docs: [{ id: 'walletId', data: () => mockWallet }],
      } as any)

      const result = await getWallet('existingUserId')
      expect(result).toEqual(mockWallet)
    })
  })

  describe('createWallet', () => {
    it('should create a new wallet', async () => {
      const mockAddDoc = setDoc as jest.MockedFunction<typeof setDoc>
      mockAddDoc.mockResolvedValueOnce({ id: 'newWalletId' } as any)

      const result = await createWallet('userId', 'USD')
      expect(result).toEqual({
        id: 'newWalletId',
        userId: 'userId',
        balance: 0,
        currency: 'USD',
      })
    })
  })

  describe('updateWalletBalance', () => {
    it('should update wallet balance for credit', async () => {
      const mockWallet = { id: 'walletId', balance: 100, currency: 'PHP' }
      const mockGetDocs = getDocs as jest.MockedFunction<typeof getDocs>
      mockGetDocs.mockResolvedValueOnce({
        empty: false,
        docs: [{ id: 'walletId', data: () => mockWallet }],
      } as any)

      const mockUpdateDoc = updateDoc as jest.MockedFunction<typeof updateDoc>
      mockUpdateDoc.mockResolvedValueOnce(undefined)

      const result = await updateWalletBalance('walletId', 50, 'credit')
      expect(result).toEqual({ ...mockWallet, balance: 150 })
    })

    it('should throw error for insufficient funds on debit', async () => {
      const mockWallet = { id: 'walletId', balance: 100, currency: 'PHP' }
      const mockGetDocs = getDocs as jest.MockedFunction<typeof getDocs>
      mockGetDocs.mockResolvedValueOnce({
        empty: false,
        docs: [{ id: 'walletId', data: () => mockWallet }],
      } as any)

      await expect(updateWalletBalance('walletId', 150, 'debit')).rejects.toThrow('Insufficient funds')
    })
  })
})

