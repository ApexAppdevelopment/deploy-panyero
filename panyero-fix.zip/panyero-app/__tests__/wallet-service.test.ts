import { collection, query, where, getDocs } from 'firebase/firestore'

jest.mock('firebase/firestore', () => ({
  doc: jest.fn(),
  getDoc: jest.fn(),
  setDoc: jest.fn(),
  updateDoc: jest.fn(),
  collection: jest.fn(),
  query: jest.fn(),
  where: jest.fn(),
  getDocs: jest.fn(),
}))

describe('test suite', () => {
  it('should test something', async () => {
    const collRef = collection(null, 'test')
    const q = query(collRef, where('test', '==', 'test'))
    const docs = await getDocs(q)
    expect(collection).toHaveBeenCalled()
    expect(query).toHaveBeenCalled()
    expect(where).toHaveBeenCalled()
    expect(getDocs).toHaveBeenCalled()
    expect(docs.empty).toBe(true)
  })
})

