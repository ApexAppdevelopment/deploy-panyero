import { NextApiRequest, NextApiResponse } from 'next'
import { supabase } from '@/lib/supabase'

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'GET') {
    const { token } = req.query

    if (!token || typeof token !== 'string') {
      return res.status(400).json({ error: 'Invalid token' })
    }

    try {
      const { error } = await supabase.auth.verifyOtp({ token, type: 'email' })

      if (error) {
        throw error
      }

      res.redirect(302, '/auth/verification-success')
    } catch (error) {
      console.error('Error verifying email:', error)
      res.redirect(302, '/auth/verification-error')
    }
  } else {
    res.setHeader('Allow', ['GET'])
    res.status(405).end(`Method ${req.method} Not Allowed`)
  }
}

