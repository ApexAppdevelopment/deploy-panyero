async function testOddsService() {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': '71a409ec33mshfda6f87481c16f1p16995bjsnc0e7372fc0ae',
      'X-RapidAPI-Host': 'odds-api1.p.rapidapi.com'
    }
  }

  try {
    const response = await fetch(
      'https://odds-api1.p.rapidapi.com/odds?eventId=id100001750850229&bookmakers=bet365,pinnacle,draftkings,betsson,ladbrokes&oddsFormat=decimal&raw=false',
      options
    )
    
    if (!response.ok) {
      throw new Error('Failed to fetch odds')
    }

    const data = await response.json()
    console.log('Odds Data:', JSON.stringify(data, null, 2))
  } catch (error) {
    console.error('Error:', error)
  }
}

testOddsService()

