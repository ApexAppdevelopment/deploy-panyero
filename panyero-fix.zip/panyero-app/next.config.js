/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
    domains: ['firebasestorage.googleapis.com'],
  },
  // Ensure Firebase works with static export
  experimental: {
    staticPageGenerationTimeout: 300,
  },
}

module.exports = nextConfig

