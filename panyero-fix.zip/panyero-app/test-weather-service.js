async function testWeatherService() {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': '59ade3810amsh5866fb91182ed4fp11b245jsn9a0da3a16e46',
      'X-RapidAPI-Host': 'weatherbit-v1-mashape.p.rapidapi.com'
    }
  }

  try {
    const response = await fetch(
      'https://weatherbit-v1-mashape.p.rapidapi.com/current?lon=38.5&lat=-78.5&units=imperial&lang=en',
      options
    )
    
    if (!response.ok) {
      throw new Error('Failed to fetch weather data')
    }

    const data = await response.json()
    console.log('Weather Data:', JSON.stringify(data, null, 2))
  } catch (error) {
    console.error('Error:', error)
  }
}

testWeatherService()

