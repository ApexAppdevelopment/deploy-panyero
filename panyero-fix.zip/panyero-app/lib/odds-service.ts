const RAPIDAPI_KEY = '71a409ec33mshfda6f87481c16f1p16995bjsnc0e7372fc0ae'
const RAPIDAPI_HOST = 'odds-api1.p.rapidapi.com'

export interface Odds {
  eventId: string
  sportKey: string
  sportTitle: string
  homeTeam: string
  awayTeam: string
  matchTime: string
  bookmakers: {
    key: string
    title: string
    markets: {
      key: string
      outcomes: {
        name: string
        price: number
      }[]
    }[]
  }[]
}

export async function getOdds(eventId: string): Promise<Odds> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST
    }
  }

  try {
    const response = await fetch(
      `https://odds-api1.p.rapidapi.com/odds?eventId=${eventId}&bookmakers=bet365,pinnacle,draftkings,betsson,ladbrokes&oddsFormat=decimal&raw=false`,
      options
    )

    if (!response.ok) {
      throw new Error('Failed to fetch odds')
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error('Error fetching odds:', error)
    throw error
  }
}

export async function getActiveEvents(): Promise<string[]> {
  // In a real app, you would fetch active events from the API
  // For now, we'll return some sample event IDs
  return [
    'id100001750850229',
    'id100001750850230',
    'id100001750850231'
  ]
}

