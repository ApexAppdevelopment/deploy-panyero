const RAPIDAPI_KEY = '59ade3810amsh5866fb91182ed4fp11b245jsn9a0da3a16e46'
const RAPIDAPI_HOST = 'betfair-sports-casino-live-tv-result-odds.p.rapidapi.com'

export interface Game {
  id: string
  name: string
  type: string
  odds: number
  startTime: string
  status: string
  minBet: number
  maxBet: number
}

export interface Market {
  id: string
  name: string
  odds: number
  status: string
}

export async function fetchGames(): Promise<Game[]> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST
    }
  }

  try {
    const response = await fetch('https://betfair-sports-casino-live-tv-result-odds.p.rapidapi.com/api/GetMarketIdsV2?market_id=1.226888545', options)
    
    if (!response.ok) {
      throw new Error('Failed to fetch games')
    }

    const data = await response.json()
    
    // Transform the API response to match our interface
    return data.markets?.map((market: any) => ({
      id: market.marketId || String(Math.random()),
      name: market.marketName || 'Unknown Game',
      type: market.eventType || 'sport',
      odds: market.odds || 1.5,
      startTime: market.startTime || new Date().toISOString(),
      status: market.status || 'open',
      minBet: 100,
      maxBet: 10000
    })) || []
  } catch (error) {
    console.error('Error fetching games:', error)
    return []
  }
}

