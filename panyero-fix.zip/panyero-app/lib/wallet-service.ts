import { collection, doc, getDoc, setDoc, updateDoc, query, where, getDocs } from 'firebase/firestore';
import { db } from './firebase';

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
  currency: string;
}

export async function getWallet(userId: string): Promise<Wallet | null> {
  const walletsRef = collection(db, 'wallets');
  const q = query(walletsRef, where("userId", "==", userId));
  const querySnapshot = await getDocs(q);

  if (querySnapshot.empty) {
    return null;
  }

  const walletDoc = querySnapshot.docs[0];
  return { id: walletDoc.id, ...walletDoc.data() } as Wallet;
}

export async function createWallet(userId: string, currency: string = 'PHP'): Promise<Wallet> {
  const walletsRef = collection(db, 'wallets');
  const newWalletRef = doc(walletsRef);
  const newWallet: Wallet = {
    id: newWalletRef.id,
    userId,
    balance: 0,
    currency,
  };

  await setDoc(newWalletRef, newWallet);
  return newWallet;
}

export async function updateWalletBalance(
  walletId: string,
  amount: number,
  type: 'credit' | 'debit'
): Promise<Wallet> {
  const walletRef = doc(db, 'wallets', walletId);
  const walletSnap = await getDoc(walletRef);

  if (!walletSnap.exists()) {
    throw new Error('Wallet not found');
  }

  const currentWallet = walletSnap.data() as Wallet;
  let newBalance: number;

  if (type === 'credit') {
    newBalance = currentWallet.balance + amount;
  } else {
    if (currentWallet.balance < amount) {
      throw new Error('Insufficient funds');
    }
    newBalance = currentWallet.balance - amount;
  }

  await updateDoc(walletRef, { balance: newBalance });

  return { ...currentWallet, balance: newBalance };
}

export async function getTransactions(userId: string): Promise<any[]> {
  // Implement getTransactions logic here
  // This is a placeholder implementation
  return [];
}

export async function placeBet(userId: string, gameId: string, amount: number): Promise<any> {
  // Implement placeBet logic here
  // This is a placeholder implementation
  return { success: true, newBalance: 0 };
}

