import { createClient } from '@supabase/supabase-js'
import { type Database } from '@/types/supabase'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey)

export type User = Database['public']['Tables']['users']['Row']
export type Profile = Database['public']['Tables']['profiles']['Row']
export type Transaction = Database['public']['Tables']['transactions']['Row']
export type Wallet = Database['public']['Tables']['wallets']['Row']
export type LotteryTicket = Database['public']['Tables']['lottery_tickets']['Row']
export type CasinoGame = Database['public']['Tables']['casino_games']['Row']

