// Make sure to set the NEXT_PUBLIC_RAPIDAPI_KEY environment variable
const RAPIDAPI_KEY = process.env.NEXT_PUBLIC_RAPIDAPI_KEY || "";
const RAPIDAPI_HOST = "weatherbit-v1-mashape.p.rapidapi.com"; // Replace if needed

export async function getCurrentWeather(lat: number, lon: number): Promise<WeatherData> {
  const options = {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': RAPIDAPI_KEY,
      'X-RapidAPI-Host': RAPIDAPI_HOST,
    }
  }

  try {
    const response = await fetch(
      `https://weatherbit-v1-mashape.p.rapidapi.com/current?lon=${lon}&lat=${lat}&units=M&lang=en`,
      options
    )

    if (!response.ok) {
      throw new Error('Failed to fetch weather data')
    }

    const data = await response.json()
    const weather = data.data[0]

    return {
      temp: weather.temp,
      humidity: weather.rh,
      windSpeed: weather.wind_spd,
      description: weather.weather.description,
      cityName: weather.city_name,
      countryCode: weather.country_code,
      sunrise: weather.sunrise,
      sunset: weather.sunset,
      feelsLike: weather.app_temp,
      uv: weather.uv,
      visibility: weather.vis,
      precip: weather.precip
    }
  } catch (error) {
    console.error('Error fetching weather data:', error)
    throw error
  }
}

interface WeatherData {
  temp: number;
  humidity: number;
  windSpeed: number;
  description: string;
  cityName: string;
  countryCode: string;
  sunrise: string;
  sunset: string;
  feelsLike: number;
  uv: number;
  visibility: number;
  precip: number;
}

