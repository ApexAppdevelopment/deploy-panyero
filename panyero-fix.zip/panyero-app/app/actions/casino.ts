"use server"

import { revalidatePath } from "next/cache"
import { placeBet } from "@/lib/wallet-service"

export async function handlePlaceBet(
  userId: string,
  gameId: string,
  betAmount: number
) {
  try {
    const result = await placeBet(userId, gameId, betAmount)
    revalidatePath('/casino')
    return result
  } catch (error) {
    console.error('Error placing bet:', error)
    return { success: false, error: 'Failed to place bet' }
  }
}

