"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"
import Link from "next/link"

export default function VerifyPage() {
  const router = useRouter()
  const { user, sendVerificationEmail } = useAuth()
  const [verificationSent, setVerificationSent] = useState(false)
  const [countdown, setCountdown] = useState(60)
  const [canResend, setCanResend] = useState(false)

  useEffect(() => {
    if (user?.emailVerified) {
      router.push("/")
    }
  }, [user, router])

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    } else {
      setCanResend(true)
    }
  }, [countdown])

  const handleResendVerification = async () => {
    try {
      await sendVerificationEmail()
      setVerificationSent(true)
      setCountdown(60)
      setCanResend(false)
      toast.success("Verification email sent")
    } catch (error) {
      console.error("Error resending verification:", error)
      toast.error("Failed to send verification email")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            Verify your email
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            We've sent a verification email to your inbox. Please check your email and click the verification link.
          </p>
        </div>
        <div className="mt-8 space-y-6">
          <Button
            onClick={handleResendVerification}
            className="w-full"
            disabled={!canResend}
          >
            {canResend ? "Resend verification email" : `Resend in ${countdown}s`}
          </Button>
          <div className="text-center">
            <Link
              href="/auth/sign-in"
              className="font-medium text-indigo-600 hover:text-indigo-500"
            >
              Back to sign in
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}

