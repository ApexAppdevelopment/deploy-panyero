import { useState } from "react"
import { useRouter } from "next/router"
import { useForm } from "react-hook-form"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { supabase } from "@/utils/supabaseClient"
import { toast } from "@/components/ui/use-toast"
import ReCAPTCHA from "react-google-recaptcha"

const ResetPassword = () => {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [message, setMessage] = useState("")
  const [captchaToken, setCaptchaToken] = useState<string | null>(null)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm()

  const handleCaptchaChange = (token: string | null) => {
    setCaptchaToken(token)
  }

  const onSubmit = async (data: any) => {
    const { email } = data
    try {
      setLoading(true)
      setMessage("")
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        captchaToken,
      })
      if (error) throw error
      setMessage("Password reset email sent. Check your inbox.")
    } catch (error: any) {
      setMessage("Failed to send reset email. Please try again.")
      console.error("Error sending reset email:", error)
      toast.error(error.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-2">
      <div className="w-full max-w-md p-8 space-y-4 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center">Reset Password</h2>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              {...register("email", {
                required: "Email is required",
                pattern: {
                  value: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/,
                  message: "Invalid email address",
                },
              })}
            />
            {errors.email && (
              <p className="text-red-500 text-xs italic">
                {errors.email.message}
              </p>
            )}
          </div>
          <ReCAPTCHA
            sitekey={process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || ''}
            onChange={handleCaptchaChange}
          />
          {message && (
            <p className="text-green-500 text-sm">{message}</p>
          )}
          <Button
            type="submit"
            className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            disabled={loading || !captchaToken}
          >
            {loading ? "Sending..." : "Send reset email"}
          </Button>
        </form>
      </div>
    </div>
  )
}

export default ResetPassword

