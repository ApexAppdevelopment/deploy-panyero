"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { CreditCard, Trash2 } from 'lucide-react'

export default function PaymentMethodsPage() {
  const { user } = useAuth()
  const [cards, setCards] = useState([
    { id: 1, last4: "4242", brand: "Visa", expMonth: 12, expYear: 2024 },
    { id: 2, last4: "1234", brand: "Mastercard", expMonth: 6, expYear: 2025 },
  ])
  const [showAddCard, setShowAddCard] = useState(false)
  const [newCard, setNewCard] = useState({ number: "", expiry: "", cvc: "" })

  const handleAddCard = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically integrate with a payment processor to tokenize and save the card
    toast.success("New card added successfully")
    setShowAddCard(false)
    setNewCard({ number: "", expiry: "", cvc: "" })
  }

  const handleRemoveCard = (id: number) => {
    // Here you would typically call an API to remove the card from the user's account
    setCards(cards.filter(card => card.id !== id))
    toast.success("Card removed successfully")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Payment Methods</h1>

        <div className="space-y-4">
          {cards.map(card => (
            <div key={card.id} className="flex items-center justify-between bg-white p-4 rounded-lg shadow">
              <div className="flex items-center">
                <CreditCard className="h-6 w-6 mr-2 text-gray-500" />
                <div>
                  <p className="font-medium">{card.brand} •••• {card.last4}</p>
                  <p className="text-sm text-gray-500">Expires {card.expMonth}/{card.expYear}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => handleRemoveCard(card.id)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
        </div>

        {!showAddCard && (
          <Button className="w-full mt-6" onClick={() => setShowAddCard(true)}>
            Add New Card
          </Button>
        )}

        {showAddCard && (
          <form onSubmit={handleAddCard} className="mt-6 space-y-4">
            <div>
              <Label htmlFor="cardNumber">Card Number</Label>
              <Input
                id="cardNumber"
                type="text"
                value={newCard.number}
                onChange={(e) => setNewCard({...newCard, number: e.target.value})}
                required
              />
            </div>
            <div className="flex gap-4">
              <div className="flex-1">
                <Label htmlFor="expiry">Expiry (MM/YY)</Label>
                <Input
                  id="expiry"
                  type="text"
                  value={newCard.expiry}
                  onChange={(e) => setNewCard({...newCard, expiry: e.target.value})}
                  required
                />
              </div>
              <div className="flex-1">
                <Label htmlFor="cvc">CVC</Label>
                <Input
                  id="cvc"
                  type="text"
                  value={newCard.cvc}
                  onChange={(e) => setNewCard({...newCard, cvc: e.target.value})}
                  required
                />
              </div>
            </div>
            <Button type="submit" className="w-full">Add Card</Button>
          </form>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

