"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { ProfileCompleteness } from "@/components/profile-completeness"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"

export default function ProfilePage() {
  const { user, getProfile } = useAuth()
  const [profile, setProfile] = useState<any>(null)
  const [completeness, setCompleteness] = useState(0)

  useEffect(() => {
    const fetchProfile = async () => {
      if (user) {
        const userProfile = await getProfile()
        setProfile(userProfile)
        calculateCompleteness(userProfile)
      }
    }
    fetchProfile()
  }, [user, getProfile])

  const calculateCompleteness = (profile: any) => {
    const fields = ['fullName', 'email', 'mobileNumber', 'seamanBookNumber', 'avatar']
    const completedFields = fields.filter(field => profile && profile[field])
    setCompleteness((completedFields.length / fields.length) * 100)
  }

  if (!profile) {
    return <div>Loading...</div>
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <div className="flex items-center space-x-4">
          <Avatar className="h-20 w-20">
            <AvatarImage src={profile.avatar} alt={profile.fullName} />
            <AvatarFallback>{profile.fullName?.charAt(0)}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-2xl font-bold">{profile.fullName}</h1>
            <p className="text-gray-600">{profile.email}</p>
          </div>
        </div>

        <ProfileCompleteness completeness={completeness} />

        <div className="grid gap-4">
          <Button asChild>
            <Link href="/profile/personal">Personal Information</Link>
          </Button>
          <Button asChild>
            <Link href="/profile/seaman-book">Seaman's Book</Link>
          </Button>
          <Button asChild>
            <Link href="/profile/payment">Payment Methods</Link>
          </Button>
          <Button asChild>
            <Link href="/profile/security">Security Settings</Link>
          </Button>
          <Button asChild>
            <Link href="/profile/preferences">Preferences</Link>
          </Button>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

