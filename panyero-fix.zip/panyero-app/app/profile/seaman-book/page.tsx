"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

export default function SeamanBookPage() {
  const { user, supabase } = useAuth()
  const [bookNumber, setBookNumber] = useState(user?.user_metadata?.seaman_book_number || "")
  const [expiryDate, setExpiryDate] = useState(user?.user_metadata?.seaman_book_expiry || "")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      setLoading(true)
      const { error } = await supabase.auth.updateUser({
        data: { 
          seaman_book_number: bookNumber,
          seaman_book_expiry: expiryDate
        }
      })
      if (error) throw error
      toast.success("Seaman's book information updated successfully")
    } catch (error) {
      console.error("Error updating seaman's book information:", error)
      toast.error("Failed to update seaman's book information")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Seaman's Book</h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="bookNumber">Seaman's Book Number</Label>
            <Input
              id="bookNumber"
              type="text"
              value={bookNumber}
              onChange={(e) => setBookNumber(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="expiryDate">Expiry Date</Label>
            <Input
              id="expiryDate"
              type="date"
              value={expiryDate}
              onChange={(e) => setExpiryDate(e.target.value)}
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full"
            disabled={loading}
          >
            {loading ? "Updating..." : "Update Seaman's Book"}
          </Button>
        </form>
      </div>

      <BottomNav />
    </main>
  )
}

