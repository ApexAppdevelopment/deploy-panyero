import { Navigation } from "@/components/navigation"
import { VoiceAssistant } from "@/components/voice-assistant"

export default function LoansPage() {
  return (
    <main className="min-h-screen bg-purple-50 pb-20">
      <div className="bg-purple-600 p-6 text-white">
        <h1 className="text-2xl font-bold">Loan Application</h1>
      </div>
      <div className="p-4">
        <form className="space-y-4">
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700">Loan Amount</label>
            <input type="number" id="amount" name="amount" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
          </div>
          <div>
            <label htmlFor="term" className="block text-sm font-medium text-gray-700">Loan Term (months)</label>
            <input type="number" id="term" name="term" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500" />
          </div>
          <div>
            <label htmlFor="purpose" className="block text-sm font-medium text-gray-700">Loan Purpose</label>
            <textarea id="purpose" name="purpose" rows={3} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-purple-500 focus:ring-purple-500"></textarea>
          </div>
          <button type="submit" className="w-full rounded-md bg-purple-600 px-4 py-2 text-white hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2">
            Apply for Loan
          </button>
        </form>
      </div>
      <Navigation />
      <VoiceAssistant />
    </main>
  )
}

