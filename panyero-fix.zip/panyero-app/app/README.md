# App Directory

This directory contains the main application pages and components for the Panyero app.

## Structure

- `page.tsx`: The main entry point and home page of the application.
- `layout.tsx`: The root layout component that wraps all pages.
- `globals.css`: Global styles for the entire application.

### Subdirectories

- `auth/`: Contains authentication-related pages (sign-in, sign-up, etc.).
- `navigation/`: Pages related to navigation tools (compass, GPS, weather, etc.).
- `wallet/`: Wallet and financial transaction pages.
- `profile/`: User profile and settings pages.
- `casino/`: Casino and betting-related pages.
- `help/`: Help and support pages.

## Key Components

- `StickyHeader`: A header component that stays at the top of the page.
- `BottomNav`: A navigation component that appears at the bottom of each page.

## Styling

This project uses Tailwind CSS for styling. Custom styles can be found in `globals.css`.

## State Management

We use React's built-in hooks for local state management. For global state, we utilize the AuthContext provided in `contexts/auth-context.tsx`.

## API Integration

API calls are typically made using custom hooks or services located in the `lib/` directory. Ensure to handle loading states and errors appropriately in each page.

## Best Practices

- Keep pages modular and focused on a single responsibility.
- Use server-side rendering (SSR) or static site generation (SSG) where appropriate for better performance.
- Implement proper error handling and loading states for all asynchronous operations.
- Ensure all pages are responsive and provide a good user experience on all device sizes.

## Adding New Pages

1. Create a new file in the appropriate subdirectory (e.g., `app/new-feature/page.tsx`).
2. Implement the page component, including necessary imports and logic.
3. Add any required API integrations or state management.
4. Ensure the page is properly styled and responsive.
5. Update the navigation components if the new page should be accessible from the main navigation.

For any questions or concerns, please contact the lead developer.

