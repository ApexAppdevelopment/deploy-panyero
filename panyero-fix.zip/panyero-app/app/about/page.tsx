import Image from 'next/image'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Wallet, Anchor, Compass, LifeBuoy } from 'lucide-react'

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">About Panyero</h1>
        
        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col md:flex-row items-center mb-6">
            <Image
              src="/assets/images/logo/logo-1024px.png"
              alt="Panyero Logo"
              width={200}
              height={200}
              className="mb-4 md:mb-0 md:mr-6"
            />
            <div>
              <h2 className="text-2xl font-semibold mb-2">Our Mission</h2>
              <p className="text-gray-600">
                Panyero is dedicated to improving the lives of seafarers by providing a comprehensive digital platform for financial management, communication, and career development.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">Key Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start">
              <Wallet className="h-8 w-8 text-blue-500 mr-3" />
              <div>
                <h3 className="font-semibold mb-1">Digital Wallet</h3>
                <p className="text-gray-600">Secure and easy-to-use digital wallet for managing finances at sea.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Anchor className="h-8 w-8 text-blue-500 mr-3" />
              <div>
                <h3 className="font-semibold mb-1">Career Tools</h3>
                <p className="text-gray-600">Access to job listings, training resources, and certification management.</p>
              </div>
            </div>
            <div className="flex items-start">
              <Compass className="h-8 w-8 text-blue-500 mr-3" />
              <div>
                <h3 className="font-semibold mb-1">Navigation Aids</h3>
                <p className="text-gray-600">Integrated navigation tools and weather updates for safer voyages.</p>
              </div>
            </div>
            <div className="flex items-start">
              <LifeBuoy className="h-8 w-8 text-blue-500 mr-3" />
              <div>
                <h3 className="font-semibold mb-1">Safety Center</h3>
                <p className="text-gray-600">Centralized hub for safety information, emergency contacts, and procedures.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4">Our Team</h2>
          <p className="text-gray-600 mb-4">
            Panyero was founded by a team of experienced maritime professionals and technology experts. We understand the unique challenges faced by seafarers and are committed to creating innovative solutions to address these needs.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
          <p className="text-gray-600 mb-2">
            Email: support@panyero.com
          </p>
          <p className="text-gray-600">
            Phone: +1 (555) 123-4567
          </p>
        </section>
      </div>

      <BottomNav />
    </main>
  )
}

