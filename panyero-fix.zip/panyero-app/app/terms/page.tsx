import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Terms and Conditions</h1>
        
        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">1. Acceptance of Terms</h2>
          <p className="mb-4">
            By accessing or using the Panyero app, you agree to be bound by these Terms and Conditions and all applicable laws and regulations. If you do not agree with any part of these terms, you may not use our services.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">2. Use of the App</h2>
          <p className="mb-4">
            You must be at least 18 years old and a registered seafarer to use the Panyero app. You are responsible for maintaining the confidentiality of your account and password. You agree to accept responsibility for all activities that occur under your account or password.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">3. Financial Services</h2>
          <p className="mb-4">
            Panyero provides digital wallet and remittance services. You agree to use these services in compliance with all applicable laws and regulations. We reserve the right to refuse service, terminate accounts, or cancel transactions at our sole discretion.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">4. Privacy</h2>
          <p className="mb-4">
            Your use of the Panyero app is also governed by our Privacy Policy. Please review our Privacy Policy to understand how we collect, use, and protect your personal information. By using our services, you consent to the collection and use of your data as described in the Privacy Policy.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">5. Intellectual Property</h2>
          <p className="mb-4">
            The content, features, and functionality of the Panyero app are owned by Panyero and are protected by international copyright, trademark, patent, trade secret, and other intellectual property laws. You may not copy, modify, distribute, sell, or lease any part of our services without our explicit permission.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">6. Limitation of Liability</h2>
          <p className="mb-4">
            Panyero and its affiliates will not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your access to or use of, or inability to access or use, the services or any content provided through the app.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">7. Changes to Terms</h2>
          <p className="mb-4">
            We reserve the right to modify these terms at any time. We will notify you of any changes by posting the new Terms and Conditions on this page and updating the "Last Updated" date. Your continued use of the app after any changes indicates your acceptance of the modified terms.
          </p>
        </section>

        <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">8. Governing Law</h2>
          <p className="mb-4">
            These Terms shall be governed and construed in accordance with the laws of [Jurisdiction], without regard to its conflict of law provisions. Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights.
          </p>
        </section>

        <p className="text-sm text-gray-600 mt-8">
          Last Updated: [Current Date]
        </p>
      </div>

      <BottomNav />
    </main>
  )
}

