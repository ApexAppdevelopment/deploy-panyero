"use client"

import { useState } from "react"
import { useAuth } from "@/contexts/auth-context"
import { sendMoney } from "@/app/actions/wallet"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { QrCode, Clock } from 'lucide-react'
import dynamic from 'next/dynamic'

const QrReader = dynamic(() => import('react-qr-reader'), { ssr: false })

export default function SendMoneyPage() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [recipientId, setRecipientId] = useState("")
  const [amount, setAmount] = useState("")
  const [description, setDescription] = useState("")
  const [showScanner, setShowScanner] = useState(false)

  const recentRecipients = [
    { id: '1', name: 'John Doe', avatar: '/placeholder.svg?height=40&width=40' },
    { id: '2', name: 'Jane Smith', avatar: '/placeholder.svg?height=40&width=40' },
    { id: '3', name: 'Bob Johnson', avatar: '/placeholder.svg?height=40&width=40' },
  ]

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    try {
      setLoading(true)
      const result = await sendMoney(
        user.id,
        recipientId,
        Number(amount),
        description
      )

      if (result.success) {
        toast.success("Money sent successfully")
        setRecipientId("")
        setAmount("")
        setDescription("")
      } else {
        toast.error(result.error || "Failed to send money")
      }
    } catch (error) {
      console.error("Error sending money:", error)
      toast.error("Failed to send money")
    } finally {
      setLoading(false)
    }
  }

  const handleScan = (data: string | null) => {
    if (data) {
      setRecipientId(data)
      setShowScanner(false)
      toast.success("QR Code scanned successfully")
    }
  }

  const handleError = (err: Error) => {
    console.error(err)
    toast.error("Error scanning QR Code")
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-6">Send Money</h1>

        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Recent Recipients</h2>
          <div className="flex space-x-4 overflow-x-auto">
            {recentRecipients.map((recipient) => (
              <button
                key={recipient.id}
                className="flex flex-col items-center transition-all duration-200 ease-in-out hover:scale-110"
                onClick={() => setRecipientId(recipient.id)}
              >
                <img src={recipient.avatar} alt={recipient.name} className="w-10 h-10 rounded-full mb-1" />
                <span className="text-sm">{recipient.name}</span>
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="recipientId">Recipient ID</Label>
            <Input
              id="recipientId"
              type="text"
              value={recipientId}
              onChange={(e) => setRecipientId(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="amount">Amount (PHP)</Label>
            <Input
              id="amount"
              type="number"
              min="1"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Input
              id="description"
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full hover-scale"
            disabled={loading}
          >
            {loading ? "Sending..." : "Send Money"}
          </Button>
        </form>

        <div className="mt-6">
          <Button variant="outline" className="w-full transition-all duration-200 ease-in-out hover:bg-blue-100 hover:text-blue-600 hover-scale" onClick={() => setShowScanner(true)}>
            <QrCode className="mr-2 h-4 w-4" />
            Scan QR Code
          </Button>
        </div>

        {showScanner && (
          <div className="mt-6">
            <QrReader
              delay={300}
              onError={handleError}
              onScan={handleScan}
              style={{ width: '100%' }}
            />
            <Button className="w-full mt-4" onClick={() => setShowScanner(false)}>
              Cancel Scan
            </Button>
          </div>
        )}
      </div>

      <BottomNav />
    </main>
  )
}

