import { Button } from '@chakra-ui/react';

function MyComponent({ loading, selectedMethod }) {
  return (
    <form onSubmit={handleSubmit}>
      {/* ... other form elements ... */}
      <Button
        type="submit"
        className="w-full hover-scale"
        disabled={loading || !selectedMethod}
      >
        {loading ? "Processing..." : "Continue"}
      </Button>
    </form>
  );
}

export default MyComponent;

