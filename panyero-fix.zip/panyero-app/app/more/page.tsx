import { Navigation } from "@/components/navigation"
import { VoiceAssistant } from "@/components/voice-assistant"
import { ServiceCard } from "@/components/service-card"
import { School, Film, Wallet, Music, Gift, LayoutDashboard, CreditCard, Banknote, ShoppingCart, Ticket, Plane, Car, Home, Zap, PhoneCall } from 'lucide-react'
import Link from 'next/link'

const services = [
  { icon: School, title: "Review", href: "/review-center" },
  { icon: Film, title: "Movies", href: "/entertainment/movies" },
  { icon: Music, title: "Music", href: "/entertainment/music" },
  { icon: Gift, title: "Rewards", href: "/rewards" },
  { icon: LayoutDashboard, title: "Dash", href: "/dashboard" },
  { icon: Wallet, title: "Lottery", href: "/lottery" },
  { icon: CreditCard, title: "Credit", href: "/credit" },
  { icon: Banknote, title: "Loans", href: "/loans" },
  { icon: ShoppingCart, title: "Shop", href: "/shopping" },
  { icon: Ticket, title: "Events", href: "/events" },
  { icon: Plane, title: "Travel", href: "/travel" },
  { icon: Car, title: "Trans", href: "/transport" },
  { icon: Home, title: "Bills", href: "/bills" },
  { icon: Zap, title: "Load", href: "/load" },
  { icon: PhoneCall, title: "Insure", href: "/insurance" }
]

export default function MorePage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-20">
      <div className="bg-purple-600 p-6 text-white">
        <h1 className="text-2xl font-bold">More Services</h1>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-4 gap-4">
          {services.map((service, index) => (
            <Link key={index} href={service.href}>
              <ServiceCard 
                icon={service.icon} 
                title={service.title}
                className="transition-all duration-300 ease-in-out transform hover:scale-105 hover:shadow-md"
              />
            </Link>
          ))}
        </div>
      </div>
      <Navigation />
      <VoiceAssistant />
    </main>
  )
}

