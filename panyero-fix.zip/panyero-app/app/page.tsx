import { Suspense } from 'react'
import dynamic from 'next/dynamic'
import { BottomNav } from "@/components/ui/bottom-nav"
import { AnimatedWelcome } from '@/components/animated-welcome'
import { AuthButtons } from '@/components/auth-buttons'
import { Skeleton } from "@/components/ui/skeleton"

const AnimatedBanners = dynamic(() => import('@/components/animated-banners'), {
  loading: () => <Skeleton className="w-full h-64" />,
  ssr: false
})

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <div className="w-full min-h-screen flex flex-col justify-between bg-gradient-to-b from-blue-100 to-white px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <AnimatedWelcome />
        <Suspense fallback={<Skeleton className="w-full h-64" />}>
          <AnimatedBanners title="Panyero" />
        </Suspense>
        <AuthButtons />
      </div>
      <BottomNav />
    </main>
  )
}

