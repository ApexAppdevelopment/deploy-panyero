"use client"

import { useState, useEffect } from 'react'
import { useAuth } from "@/contexts/auth-context"
import { getWallet, getTransactions } from "@/lib/wallet-service"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { ActionCard } from "@/components/ui/action-card"
import { TransactionList } from "@/components/ui/transaction-list"
import { Wallet, ArrowUpRight, ArrowDownLeft } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { toast } from "sonner"

export default function WalletPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [balance, setBalance] = useState(0)
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchWalletData = async () => {
      if (user) {
        try {
          const wallet = await getWallet(user.id)
          setBalance(wallet?.balance || 0)
          const fetchedTransactions = await getTransactions(user.id)
          setTransactions(fetchedTransactions)
        } catch (error) {
          console.error("Error fetching wallet data:", error)
          toast.error("Failed to load wallet data")
        } finally {
          setLoading(false)
        }
      }
    }

    fetchWalletData()
  }, [user])

  if (loading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>
  }

  return (
    <main className="min-h-screen bg-background pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">My Wallet</h1>
        
        <div className="bg-primary text-primary-foreground p-6 rounded-lg shadow-md">
          <h2 className="text-xl mb-2">Current Balance</h2>
          <p className="text-3xl font-bold">₱{balance.toFixed(2)}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ActionCard
            title="Cash In"
            description="Add funds to your wallet"
            icon={ArrowDownLeft}
            actionLabel="Add Money"
            onAction={() => router.push('/cash-in')}
          />
          <ActionCard
            title="Send Money"
            description="Transfer funds to another account"
            icon={ArrowUpRight}
            actionLabel="Send"
            onAction={() => router.push('/send')}
          />
        </div>

        <TransactionList transactions={transactions} />
      </div>

      <BottomNav />
    </main>
  )
}

