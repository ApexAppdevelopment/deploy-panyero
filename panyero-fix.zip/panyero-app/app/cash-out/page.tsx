import React from 'react';

interface CashOutMethod {
  id: string;
  name: string;
}

interface Props {
  methods: CashOutMethod[];
  selectedMethod: string | null;
  onSelectMethod: (methodId: string) => void;
}

const CashOutMethodSelection: React.FC<Props> = ({ methods, selectedMethod, onSelectMethod }) => {
  return (
    <div>
      {methods.map((method) => (
        <div
          key={method.id}
          onClick={() => onSelectMethod(method.id)}
          className={`flex items-center gap-4 rounded-lg border p-4 cursor-pointer transition-all duration-200 ease-in-out ${
            selectedMethod === method.id ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
          }`}
        >
          <div>{method.name}</div>
        </div>
      ))}
    </div>
  );
};

export default CashOutMethodSelection;

