import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Compass, MapPin, CloudRain, Route } from 'lucide-react'
import Link from 'next/link'

const navigationTools = [
  {
    title: "Digital Compass",
    icon: Compass,
    description: "Get accurate bearings with our digital compass",
    href: "/navigation/digital-compass"
  },
  {
    title: "GPS Navigation",
    icon: MapPin,
    description: "Navigate with precision using GPS technology",
    href: "/navigation/gps"
  },
  {
    title: "Weather Updates",
    icon: CloudRain,
    description: "Stay informed with real-time weather forecasts",
    href: "/navigation/weather"
  },
  {
    title: "Route Planning",
    icon: Route,
    description: "Plan your voyages efficiently and safely",
    href: "/navigation/route-planning"
  }
]

export default function NavigationPage() {
  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto p-4 space-y-6">
        <h1 className="text-2xl font-bold">Navigation Tools</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {navigationTools.map((tool) => (
            <Card key={tool.title} className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center space-x-4">
                <tool.icon className="h-8 w-8 text-blue-600" />
                <CardTitle>{tool.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{tool.description}</p>
                <Button asChild className="w-full">
                  <Link href={tool.href}>Open Tool</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

