"use client"

import { useState, useEffect } from 'react'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Navigation } from 'lucide-react'
import { toast } from "sonner"

export default function GPSNavigationPage() {
  const [position, setPosition] = useState<GeolocationPosition | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => setPosition(position),
        (error) => setError(error.message)
      )
    } else {
      setError('Geolocation is not supported by your browser')
    }
  }, [])

  const refreshPosition = () => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setPosition(position)
        toast.success("Position updated successfully")
      },
      (error) => {
        setError(error.message)
        toast.error("Failed to update position")
      }
    )
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto p-4 space-y-6">
        <h1 className="text-2xl font-bold">GPS Navigation</h1>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <MapPin className="mr-2 h-6 w-6 text-blue-600" />
              Current Position
            </CardTitle>
          </CardHeader>
          <CardContent>
            {error ? (
              <p className="text-red-500">{error}</p>
            ) : position ? (
              <div>
                <p>Latitude: {position.coords.latitude}</p>
                <p>Longitude: {position.coords.longitude}</p>
                <p>Accuracy: {position.coords.accuracy} meters</p>
              </div>
            ) : (
              <p>Loading position...</p>
            )}
            <Button onClick={refreshPosition} className="mt-4">
              <Navigation className="mr-2 h-4 w-4" />
              Refresh Position
            </Button>
          </CardContent>
        </Card>

        {/* Placeholder for map component */}
        <Card>
          <CardHeader>
            <CardTitle>Map View</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-200 h-64 flex items-center justify-center">
              <p>Map component will be implemented here</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

