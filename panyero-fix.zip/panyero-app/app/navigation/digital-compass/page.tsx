"use client"

import { useState, useEffect } from 'react'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Compass } from 'lucide-react'

export default function DigitalCompassPage() {
  const [heading, setHeading] = useState<number | null>(null)

  useEffect(() => {
    if ('ondeviceorientationabsolute' in window) {
      window.addEventListener('deviceorientationabsolute', handleOrientation)
    } else if ('ondeviceorientation' in window) {
      window.addEventListener('deviceorientation', handleOrientation)
    }

    return () => {
      if ('ondeviceorientationabsolute' in window) {
        window.removeEventListener('deviceorientationabsolute', handleOrientation)
      } else if ('ondeviceorientation' in window) {
        window.removeEventListener('deviceorientation', handleOrientation)
      }
    }
  }, [])

  const handleOrientation = (event: DeviceOrientationEvent) => {
    let direction = event.alpha
    if (direction !== null) {
      setHeading(Math.round(direction))
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Digital Compass</h1>
        
        <div className="flex flex-col items-center justify-center space-y-4">
          <Compass className="w-32 h-32 text-blue-600" style={{ transform: `rotate(${heading}deg)` }} />
          <p className="text-2xl font-bold">{heading !== null ? `${heading}°` : 'Calibrating...'}</p>
          <p className="text-gray-600">
            {heading !== null ? getCardinalDirection(heading) : 'Please move your device in a figure-8 pattern to calibrate'}
          </p>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

function getCardinalDirection(angle: number): string {
  const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
  return directions[Math.round(angle / 45) % 8]
}

