"use client"

import { useState, useEffect } from 'react'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CloudRain, Wind, Thermometer, Droplets, Sun, Sunrise, Sunset, Eye, AlertTriangle } from 'lucide-react'
import { toast } from "sonner"
import { getCurrentWeather, type WeatherData } from "@/lib/weather-service"

export default function WeatherUpdatesPage() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchWeather = async () => {
    setLoading(true)
    setError(null)
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject)
      })

      const weatherData = await getCurrentWeather(
        position.coords.latitude,
        position.coords.longitude
      )
      setWeather(weatherData)
      toast.success("Weather data updated")
    } catch (err) {
      console.error('Error:', err)
      setError('Failed to fetch weather data. Please check your connection and try again.')
      toast.error("Failed to update weather data")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWeather()
  }, [])

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto p-4 space-y-6">
        <h1 className="text-2xl font-bold">Weather Updates</h1>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CloudRain className="mr-2 h-6 w-6 text-blue-600" />
              Current Weather {weather?.cityName && `in ${weather.cityName}, ${weather.countryCode}`}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {error ? (
              <div className="flex items-center text-red-500">
                <AlertTriangle className="mr-2 h-5 w-5" />
                <span>{error}</span>
              </div>
            ) : loading ? (
              <div className="flex justify-center items-center h-40">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
              </div>
            ) : weather ? (
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <Thermometer className="mr-2 h-5 w-5 text-red-500" />
                    <span>Temperature: {weather.temp}°F</span>
                  </div>
                  <div className="flex items-center">
                    <Droplets className="mr-2 h-5 w-5 text-blue-500" />
                    <span>Humidity: {weather.humidity}%</span>
                  </div>
                  <div className="flex items-center">
                    <Wind className="mr-2 h-5 w-5 text-gray-500" />
                    <span>Wind Speed: {weather.windSpeed.toFixed(1)} mph</span>
                  </div>
                  <div className="flex items-center">
                    <CloudRain className="mr-2 h-5 w-5 text-gray-500" />
                    <span>Conditions: {weather.description}</span>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3">Additional Information</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center">
                      <Sun className="mr-2 h-5 w-5 text-yellow-500" />
                      <span>UV Index: {weather.uv}</span>
                    </div>
                    <div className="flex items-center">
                      <Eye className="mr-2 h-5 w-5 text-gray-500" />
                      <span>Visibility: {weather.visibility} km</span>
                    </div>
                    <div className="flex items-center">
                      <Sunrise className="mr-2 h-5 w-5 text-orange-500" />
                      <span>Sunrise: {weather.sunrise}</span>
                    </div>
                    <div className="flex items-center">
                      <Sunset className="mr-2 h-5 w-5 text-purple-500" />
                      <span>Sunset: {weather.sunset}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">No weather data available</div>
            )}
            <Button 
              onClick={fetchWeather} 
              className="mt-4" 
              disabled={loading}
            >
              {loading ? "Updating..." : "Refresh Weather"}
            </Button>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

