"use client"

import { useState } from 'react'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Route, Anchor, Clock } from 'lucide-react'
import { toast } from "sonner"

export default function RoutePlanningPage() {
  const [startPort, setStartPort] = useState('')
  const [endPort, setEndPort] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically call an API to calculate the route
    toast.success(`Route planned from ${startPort} to ${endPort}`)
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="container mx-auto p-4 space-y-6">
        <h1 className="text-2xl font-bold">Route Planning</h1>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Route className="mr-2 h-6 w-6 text-blue-600" />
              Plan Your Route
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="startPort">Start Port</Label>
                <Input
                  id="startPort"
                  value={startPort}
                  onChange={(e) => setStartPort(e.target.value)}
                  placeholder="Enter start port"
                  required
                />
              </div>
              <div>
                <Label htmlFor="endPort">End Port</Label>
                <Input
                  id="endPort"
                  value={endPort}
                  onChange={(e) => setEndPort(e.target.value)}
                  placeholder="Enter end port"
                  required
                />
              </div>
              <Button type="submit" className="w-full">
                Plan Route
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Placeholder for route details */}
        <Card>
          <CardHeader>
            <CardTitle>Route Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex items-center">
                <Anchor className="mr-2 h-5 w-5 text-blue-600" />
                <span>Total Distance: -- nautical miles</span>
              </div>
              <div className="flex items-center">
                <Clock className="mr-2 h-5 w-5 text-blue-600" />
                <span>Estimated Travel Time: -- hours</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Placeholder for map component */}
        <Card>
          <CardHeader>
            <CardTitle>Route Map</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-200 h-64 flex items-center justify-center">
              <p>Route map component will be implemented here</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <BottomNav />
    </main>
  )
}

