"use client"

import { useState } from "react"
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Book, CheckCircle, Clock, ArrowRight } from 'lucide-react'

const courses = [
  { id: 1, title: "Maritime Law", progress: 75, duration: "2h 30m" },
  { id: 2, title: "Navigation Techniques", progress: 50, duration: "3h 45m" },
  { id: 3, title: "Safety Procedures", progress: 90, duration: "1h 15m" },
  { id: 4, title: "Ship Maintenance", progress: 30, duration: "4h 00m" },
  { id: 5, title: "Environmental Regulations", progress: 0, duration: "2h 15m" },
]

const certifications = [
  { id: 1, title: "Basic Safety Training", expiryDate: "2025-12-31" },
  { id: 2, title: "GMDSS Certification", expiryDate: "2024-06-30" },
]

export default function ReviewCenterPage() {
  const [activeCourses, setActiveCourses] = useState(courses.filter(course => course.progress > 0))
  const [availableCourses, setAvailableCourses] = useState(courses.filter(course => course.progress === 0))

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Review Center</h1>
        
        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Active Courses</h2>
          <div className="space-y-4">
            {activeCourses.map(course => (
              <div key={course.id} className="border-b pb-4 last:border-b-0 last:pb-0">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="font-medium">{course.title}</h3>
                  <span className="text-sm text-gray-500">{course.progress}%</span>
                </div>
                <Progress value={course.progress} className="mb-2" />
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {course.duration}
                  </span>
                  <Button variant="ghost" size="sm" className="text-blue-500 hover:text-blue-700">
                    Continue <ArrowRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">Available Courses</h2>
          <div className="space-y-4">
            {availableCourses.map(course => (
              <div key={course.id} className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium">{course.title}</h3>
                  <span className="text-sm text-gray-500">{course.duration}</span>
                </div>
                <Button variant="outline" size="sm">Start Course</Button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg p-4 shadow-sm">
          <h2 className="text-lg font-semibold mb-4">My Certifications</h2>
          <div className="space-y-4">
            {certifications.map(cert => (
              <div key={cert.id} className="flex justify-between items-center">
                <div className="flex items-center">
                  <CheckCircle className="w-5 h-5 text-green-500 mr-2" />
                  <div>
                    <h3 className="font-medium">{cert.title}</h3>
                    <span className="text-sm text-gray-500">Valid until {cert.expiryDate}</span>
                  </div>
                </div>
                <Button variant="ghost" size="sm">View</Button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

