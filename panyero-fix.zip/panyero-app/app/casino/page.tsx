"use client"

import { useState, useEffect } from 'react'
import { StickyHeader } from "@/components/ui/sticky-header"
import { BottomNav } from "@/components/ui/bottom-nav"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { getOdds, getActiveEvents, type Odds } from "@/lib/odds-service"
import { useAuth } from "@/contexts/auth-context"
import { toast } from "sonner"
import Link from "next/link"
import { Loader2 } from 'lucide-react'

function OddsSkeleton() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          <Skeleton className="h-6 w-3/4" />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
          <Skeleton className="h-10 w-32" />
          <Skeleton className="h-4 w-1/2" />
        </div>
      </CardContent>
    </Card>
  )
}

export default function CasinoPage() {
  const { user } = useAuth()
  const [odds, setOdds] = useState<Odds[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedBets, setSelectedBets] = useState<{[key: string]: number}>({})

  useEffect(() => {
    const fetchOdds = async () => {
      try {
        setLoading(true)
        const eventIds = await getActiveEvents()
        const oddsData = await Promise.all(
          eventIds.map(id => getOdds(id))
        )
        setOdds(oddsData)
      } catch (err) {
        console.error('Error fetching odds:', err)
        setError('Failed to load betting odds')
      } finally {
        setLoading(false)
      }
    }

    fetchOdds()
  }, [])

  const handleBetAmountChange = (eventId: string, amount: string) => {
    setSelectedBets(prev => ({
      ...prev,
      [eventId]: parseFloat(amount) || 0
    }))
  }

  const handlePlaceBet = async (eventId: string, odds: Odds) => {
    if (!user) {
      toast.error("Please sign in to place bets")
      return
    }

    const betAmount = selectedBets[eventId]
    if (!betAmount || betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    try {
      // Here you would integrate with your betting system
      toast.success(`Bet of ₱${betAmount} placed on ${odds.homeTeam} vs ${odds.awayTeam}`)
      setSelectedBets(prev => ({
        ...prev,
        [eventId]: 0
      }))
    } catch (error) {
      toast.error("Failed to place bet")
    }
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-gray-50 pb-24">
        <StickyHeader />
        <div className="p-4 space-y-6">
          <h1 className="text-2xl font-bold">Sports Betting</h1>
          <div className="text-center py-12">
            <p className="text-lg text-gray-500 mb-4">Please sign in to view and place bets</p>
            <Button asChild>
              <Link href="/auth/sign-in">Sign In</Link>
            </Button>
          </div>
        </div>
        <BottomNav />
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gray-50 pb-24">
      <StickyHeader />
      
      <div className="p-4 space-y-6">
        <h1 className="text-2xl font-bold">Sports Betting</h1>

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <OddsSkeleton key={i} />
            ))}
          </div>
        ) : error ? (
          <div className="text-center py-12 text-red-500">{error}</div>
        ) : (
          <div className="grid gap-4">
            {odds.map((event) => (
              <Card key={event.eventId}>
                <CardHeader>
                  <CardTitle className="flex justify-between items-center">
                    <span>{event.homeTeam} vs {event.awayTeam}</span>
                    <Badge>{event.sportTitle}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      {event.bookmakers[0]?.markets[0]?.outcomes.map((outcome, index) => (
                        <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                          <span>{outcome.name}</span>
                          <span className="font-semibold">{outcome.price}</span>
                        </div>
                      ))}
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Input
                        type="number"
                        placeholder="Bet amount"
                        value={selectedBets[event.eventId] || ""}
                        onChange={(e) => handleBetAmountChange(event.eventId, e.target.value)}
                        className="w-32"
                      />
                      <Button onClick={() => handlePlaceBet(event.eventId, event)}>
                        Place Bet
                      </Button>
                    </div>

                    <p className="text-sm text-gray-500">
                      Match Time: {new Date(event.matchTime).toLocaleString()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <div className="bg-yellow-50 rounded-lg p-4 mt-6">
          <h2 className="text-lg font-semibold mb-2">Responsible Gaming</h2>
          <p className="text-sm text-gray-600">
            Please gamble responsibly. Set limits on your betting and only bet what you can afford to lose.
            If you need help, contact our support team.
          </p>
        </div>
      </div>

      <BottomNav />
    </main>
  )
}

