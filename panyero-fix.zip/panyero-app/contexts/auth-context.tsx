"use client"

import React, { createContext, useContext, useState, useEffect } from 'react'
import { 
  User,
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  onAuthStateChanged,
  sendEmailVerification,
  sendPasswordResetEmail,
  FirebaseError
} from 'firebase/auth'
import { doc, setDoc, getDoc } from 'firebase/firestore'
import { auth, db } from '@/lib/firebase'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface AuthContextType {
  user: User | null
  signUp: (email: string, password: string, mobileNumber: string, referralAccount: string) => Promise<void>
  signIn: (email: string, password: string) => Promise<void>
  signOut: () => Promise<void>
  getProfile: () => Promise<any>
  sendVerificationEmail: () => Promise<void>
  resetPassword: (email: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user)
    })
    return () => unsubscribe()
  }, [])

  const signUp = async (email: string, password: string, mobileNumber: string, referralAccount: string) => {
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password)
      const user = userCredential.user

      await setDoc(doc(db, 'users', user.uid), {
        email,
        mobileNumber,
        referralAccount,
        createdAt: new Date(),
        isPhoneVerified: false,
      })

      toast.success('Account created successfully. Please verify your email.')
      await sendEmailVerification(user)
      router.push('/auth/verify')
    } catch (error) {
      if (error instanceof FirebaseError) {
        switch (error.code) {
          case 'auth/email-already-in-use':
            toast.error('This email is already in use. Please try another one.')
            break;
          case 'auth/invalid-email':
            toast.error('Invalid email address. Please check and try again.')
            break;
          case 'auth/weak-password':
            toast.error('Password is too weak. Please use a stronger password.')
            break;
          default:
            toast.error('An error occurred during sign up. Please try again.')
        }
      } else {
        toast.error('An unexpected error occurred. Please try again.')
      }
      console.error("Error during sign up:", error)
    }
  }

  const signIn = async (email: string, password: string) => {
    try {
      await signInWithEmailAndPassword(auth, email, password)
      router.push('/')
    } catch (error) {
      if (error instanceof FirebaseError) {
        switch (error.code) {
          case 'auth/user-not-found':
          case 'auth/wrong-password':
            toast.error('Invalid email or password. Please try again.')
            break;
          case 'auth/user-disabled':
            toast.error('This account has been disabled. Please contact support.')
            break;
          case 'auth/too-many-requests':
            toast.error('Too many failed login attempts. Please try again later.')
            break;
          default:
            toast.error('An error occurred during sign in. Please try again.')
        }
      } else {
        toast.error('An unexpected error occurred. Please try again.')
      }
      console.error("Error during sign in:", error)
    }
  }

  const signOut = async () => {
    try {
      await firebaseSignOut(auth)
      router.push('/auth/sign-in')
    } catch (error) {
      console.error("Error during sign out:", error)
      throw error
    }
  }

  const getProfile = async () => {
    if (!user) return null
    const docRef = doc(db, 'users', user.uid)
    const docSnap = await getDoc(docRef)
    return docSnap.exists() ? docSnap.data() : null
  }

  const sendVerificationEmail = async () => {
    if (user) {
      try {
        await sendEmailVerification(user)
        toast.success("Verification email sent. Please check your inbox.")
      } catch (error) {
        console.error("Error sending verification email:", error)
        throw error
      }
    }
  }

  const resetPassword = async (email: string) => {
    try {
      await sendPasswordResetEmail(auth, email)
      toast.success("Password reset email sent. Please check your inbox.")
    } catch (error) {
      console.error("Error sending password reset email:", error)
      throw error
    }
  }

  const value = {
    user,
    signUp,
    signIn,
    signOut,
    getProfile,
    sendVerificationEmail,
    resetPassword,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

