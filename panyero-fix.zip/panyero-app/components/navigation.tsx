"use client"

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Send, Plane, Calculator, Menu } from 'lucide-react'
import { cn } from "@/lib/utils"

const navItems = [
  { icon: Home, label: 'Home', href: '/' },
  { icon: Send, label: 'Send', href: '/send' },
  { icon: Plane, label: 'Flights', href: '/flights' },
  { icon: Calculator, label: 'Loans', href: '/loans' },
  { icon: Menu, label: 'More', href: '/more' },
]

export function Navigation() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 border-t bg-white">
      <div className="flex justify-around">
        {navItems.map(({ icon: Icon, label, href }) => (
          <Link key={href} href={href} className="flex-1">
            <div
              className={cn(
                "flex flex-col items-center py-2",
                pathname === href ? "text-purple-600" : "text-gray-600"
              )}
            >
              <Icon className="h-6 w-6" />
              <span className="text-xs">{label}</span>
            </div>
          </Link>
        ))}
      </div>
    </nav>
  )
}

