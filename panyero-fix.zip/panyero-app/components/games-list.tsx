"use client"

import { useState, useEffect } from 'react'
import { fetchGames, Game } from "@/lib/betting-service"
import { placeBet, getWallet } from "@/lib/wallet-service"
import { useAuth } from "@/contexts/auth-context"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Clock, Trophy, Users, Wallet } from 'lucide-react'
import { toast } from "sonner"
import Link from 'next/link'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

export function GamesList() {
  const { user } = useAuth()
  const [games, setGames] = useState<Game[]>([])
  const [loading, setLoading] = useState(true)
  const [betAmounts, setBetAmounts] = useState<{ [key: string]: string }>({})
  const [userBalance, setUserBalance] = useState(0)

  useEffect(() => {
    const loadGames = async () => {
      const fetchedGames = await fetchGames()
      setGames(fetchedGames)
      setLoading(false)
    }
    loadGames()
  }, [])

  useEffect(() => {
    const loadBalance = async () => {
      if (user) {
        const wallet = await getWallet(user.id)
        setUserBalance(wallet?.balance || 0)
      }
    }
    loadBalance()
  }, [user])

  const handleBetAmountChange = (gameId: string, amount: string) => {
    setBetAmounts(prev => ({ ...prev, [gameId]: amount }))
  }

  const handlePlaceBet = async (game: Game) => {
    if (!user) {
      toast.error("Please sign in to place a bet")
      return
    }

    const betAmount = parseFloat(betAmounts[game.id] || "0")
    if (isNaN(betAmount) || betAmount <= 0) {
      toast.error("Please enter a valid bet amount")
      return
    }

    if (betAmount < game.minBet) {
      toast.error(`Minimum bet amount is ₱${game.minBet}`)
      return
    }

    if (betAmount > game.maxBet) {
      toast.error(`Maximum bet amount is ₱${game.maxBet}`)
      return
    }

    if (betAmount > userBalance) {
      toast.error(
        <div className="flex flex-col gap-2">
          <p>Insufficient balance</p>
          <Button asChild variant="outline" size="sm">
            <Link href="/cash-in">Add Funds</Link>
          </Button>
        </div>
      )
      return
    }

    const result = await placeBet(user.id, game.id, betAmount)
    if (result.success) {
      toast.success(`Bet of ₱${betAmount} placed on ${game.name}`)
      setUserBalance(result.newBalance || 0)
      setBetAmounts(prev => ({ ...prev, [game.id]: "" }))
    } else {
      toast.error(result.error || "Failed to place bet")
    }
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader>
              <div className="h-6 bg-gray-200 rounded w-3/4"></div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-5/6"></div>
              </div>
            </CardContent>
            <CardFooter>
              <div className="h-10 bg-gray-200 rounded w-full"></div>
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Available Games</h2>
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <div className="flex items-center gap-2 bg-white p-2 rounded-lg shadow">
                <Wallet className="h-5 w-5" />
                <span className="font-semibold">₱{userBalance.toFixed(2)}</span>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p>Your current balance</p>
              {userBalance === 0 && (
                <Link href="/cash-in" className="text-sm text-blue-500 hover:underline">
                  Add funds
                </Link>
              )}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {games.map((game) => (
          <Card key={game.id}>
            <CardHeader>
              <CardTitle className="flex justify-between items-center">
                <span>{game.name}</span>
                <Badge variant="outline">{game.type}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{new Date(game.startTime).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Trophy className="h-4 w-4" />
                    <span>Odds: {game.odds}</span>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor={`bet-${game.id}`}>Place your bet</Label>
                  <div className="flex gap-2">
                    <Input
                      id={`bet-${game.id}`}
                      type="number"
                      min={game.minBet}
                      max={game.maxBet}
                      step="100"
                      placeholder={`Min: ₱${game.minBet}`}
                      value={betAmounts[game.id] || ""}
                      onChange={(e) => handleBetAmountChange(game.id, e.target.value)}
                    />
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            onClick={() => handlePlaceBet(game)}
                            disabled={!betAmounts[game.id] || parseFloat(betAmounts[game.id]) <= 0}
                          >
                            Bet
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          {userBalance === 0 ? (
                            <p>Add funds to place bets</p>
                          ) : (
                            <p>Place bet on {game.name}</p>
                          )}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </div>
                  <p className="text-xs text-gray-500">
                    Min: ₱{game.minBet} | Max: ₱{game.maxBet}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

