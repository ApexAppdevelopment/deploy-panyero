import { Card, CardContent } from "@/components/ui/card"
import { TypeIcon as type, LucideIcon } from 'lucide-react'

interface ServiceCardProps {
  icon: LucideIcon
  title: string
  amount?: string
  className?: string
}

export function ServiceCard({ icon: Icon, title, amount, className }: ServiceCardProps) {
  return (
    <Card className={`hover:bg-accent ${className}`}>
      <CardContent className="flex flex-col items-center justify-center p-2">
        <Icon className="mb-1 h-6 w-6 text-purple-600" />
        <div className="text-xs font-medium text-center leading-tight">{title}</div>
        {amount && <div className="text-xs text-muted-foreground">{amount}</div>}
      </CardContent>
    </Card>
  )
}

