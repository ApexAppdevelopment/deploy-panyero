'use client'

import Image from 'next/image'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'

const images = [
  {
    src: "https://firebasestorage.googleapis.com/v0/b/potent-bulwark-434423-t6.appspot.com/o/IMG_20241130_125005.jpg?alt=media&token=6a2efc5b-94f7-408f-8e2c-70cb3a1f39bc",
    alt: "Seafarer on ship"
  },
  {
    src: "/placeholder.svg?height=800&width=600",
    alt: "Ship at sea"
  },
  {
    src: "/placeholder.svg?height=800&width=600",
    alt: "Seafarers working"
  }
]

export function ImageShowcase() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <div ref={ref} className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
      {images.map((image, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5, delay: index * 0.2 }}
          className="relative h-[calc(100vh-200px)] md:h-[600px] rounded-lg overflow-hidden shadow-lg"
        >
          <Image
            src={image.src}
            alt={image.alt}
            layout="fill"
            objectFit="cover"
            className="transition-transform duration-300 hover:scale-105"
          />
        </motion.div>
      ))}
    </div>
  )
}

