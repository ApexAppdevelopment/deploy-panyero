import { Wallet, Compass, LifeBuoy, Banknote } from 'lucide-react'

const features = [
  { icon: Wallet, title: "Digital Wallet", description: "Manage your finances at sea" },
  { icon: Compass, title: "Navigation Tools", description: "Stay on course with advanced navigation" },
  { icon: LifeBuoy, title: "Safety Center", description: "Access critical safety information" },
  { icon: Banknote, title: "Easy Remittance", description: "Send money home securely" },
]

export function FeatureOverview() {
  return (
    <div className="grid grid-cols-2 gap-4 my-8">
      {features.map((feature, index) => (
        <div key={index} className="flex flex-col items-center text-center p-4 bg-white rounded-lg shadow-md">
          <feature.icon className="h-8 w-8 text-blue-600 mb-2" />
          <h3 className="font-semibold mb-1">{feature.title}</h3>
          <p className="text-sm text-gray-600">{feature.description}</p>
        </div>
      ))}
    </div>
  )
}

