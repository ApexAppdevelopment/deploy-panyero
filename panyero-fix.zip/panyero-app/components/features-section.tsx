'use client'

import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Anchor, Compass, Wallet } from 'lucide-react'

const features = [
  {
    icon: Anchor,
    title: "Ship Management",
    description: "Efficiently manage your vessel's operations and maintenance schedules."
  },
  {
    icon: Compass,
    title: "Navigation Tools",
    description: "Access state-of-the-art navigation tools and real-time weather updates."
  },
  {
    icon: Wallet,
    title: "Financial Services",
    description: "Manage your finances at sea with our secure digital wallet and remittance services."
  }
]

export function FeaturesSection() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <div ref={ref} className="py-8">
      <h2 className="text-3xl font-bold text-center text-white mb-8 shadow-text">Our Features</h2>
      <div className="space-y-6">
        {features.map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 50 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: index * 0.2 }}
            className="bg-white bg-opacity-80 p-6 rounded-lg shadow-lg"
          >
            <feature.icon className="h-12 w-12 text-blue-600 mb-4" />
            <h3 className="text-xl font-semibold text-blue-900 mb-2">{feature.title}</h3>
            <p className="text-blue-700">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

