import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface ResponsibleGamingModalProps {
  isOpen: boolean
  onClose: () => void
  onSetLimits: (dailyLimit: number, weeklyLimit: number, monthlyLimit: number) => void
}

export function ResponsibleGamingModal({ isOpen, onClose, onSetLimits }: ResponsibleGamingModalProps) {
  const [dailyLimit, setDailyLimit] = useState("")
  const [weeklyLimit, setWeeklyLimit] = useState("")
  const [monthlyLimit, setMonthlyLimit] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSetLimits(Number(dailyLimit), Number(weeklyLimit), Number(monthlyLimit))
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Set Gaming Limits</DialogTitle>
          <DialogDescription>
            Set your daily, weekly, and monthly gaming limits to promote responsible gaming.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <Label htmlFor="dailyLimit">Daily Limit (₱)</Label>
              <Input
                id="dailyLimit"
                type="number"
                value={dailyLimit}
                onChange={(e) => setDailyLimit(e.target.value)}
                min="0"
                step="100"
                required
              />
            </div>
            <div>
              <Label htmlFor="weeklyLimit">Weekly Limit (₱)</Label>
              <Input
                id="weeklyLimit"
                type="number"
                value={weeklyLimit}
                onChange={(e) => setWeeklyLimit(e.target.value)}
                min="0"
                step="100"
                required
              />
            </div>
            <div>
              <Label htmlFor="monthlyLimit">Monthly Limit (₱)</Label>
              <Input
                id="monthlyLimit"
                type="number"
                value={monthlyLimit}
                onChange={(e) => setMonthlyLimit(e.target.value)}
                min="0"
                step="100"
                required
              />
            </div>
          </div>
          <DialogFooter className="mt-6">
            <Button type="submit">Set Limits</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

