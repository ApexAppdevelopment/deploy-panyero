import { Progress } from "@/components/ui/progress"

interface ProfileCompletenessProps {
  completeness: number
}

export function ProfileCompleteness({ completeness }: ProfileCompletenessProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm">
      <h2 className="text-lg font-semibold mb-2">Profile Completeness</h2>
      <Progress value={completeness} className="mb-2" />
      <p className="text-sm text-muted-foreground">
        {completeness < 100
          ? `Your profile is ${completeness}% complete. Complete your profile to unlock all features.`
          : "Great job! Your profile is complete."}
      </p>
    </div>
  )
}

