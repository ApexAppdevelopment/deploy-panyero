"use client"

import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

interface Tab {
  href: string
  label: string
}

interface NavigationProps {
  tabs: Tab[]
}

const Navigation: React.FC<NavigationProps> = ({ tabs }) => {
  const location = useLocation()
  const pathname = location.pathname

  return (
    <div>
      <header className="sticky top-0 z-50 w-full bg-white shadow-md">
        <div className="flex justify-between items-center p-4">
          <div className="flex items-center">
            <Avatar className="h-8 w-8 cursor-pointer transition-transform duration-200 ease-in-out hover:scale-110">
              <AvatarImage src="/placeholder-user.jpg" alt="User avatar" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
            {/* rest of the logo/title code here */}
          </div>
          <div className="flex space-x-4">
            {tabs.map((tab) => (
              <a
                key={tab.href}
                href={tab.href}
                className={`min-w-fit rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 ease-in-out ${
                  pathname === tab.href ? "bg-blue-600 text-white" : "text-gray-600 hover:bg-blue-100 hover:text-blue-600"
                }`}
              >
                {tab.label}
              </a>
            ))}
          </div>
        </div>
      </header>
      {/* rest of the code here */}
    </div>
  )
}

export default Navigation

